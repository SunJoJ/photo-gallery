package com.example.app3;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.DragEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.theartofdev.edmodo.cropper.CropImage;
import com.yalantis.ucrop.UCrop;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import uk.co.senab.photoview.PhotoViewAttacher;

public class PageFragment extends Fragment {

    private String imageResource;
    View rootView;
    ImageView imageView;
    MyInterface mCallback;

    public interface MyInterface {
        void onTrigger(ArrayList<String> images_paths);

    }

    public static PageFragment getInstance(String resourceID) {
        PageFragment f = new PageFragment();
        Bundle args = new Bundle();
        args.putString("image_source", resourceID);
        f.setArguments(args);
        return f;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        try {
            mCallback = (MyInterface ) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString()
                    + " must implement MyInterface ");
        }

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        imageResource = getArguments().getString("image_source");
        setHasOptionsMenu(true);

    }

    @Override
    public void onCreateOptionsMenu(
            Menu menu, MenuInflater inflater) {
        menu.clear();
        inflater.inflate(R.menu.full_image_menu, menu);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.share:
                Intent share = new Intent(Intent.ACTION_SEND_MULTIPLE);
                share.setType("image/png");
                ArrayList<Uri> images =new ArrayList<Uri>();
                images.add(Uri.parse("file:///"+imageResource));
                share.putParcelableArrayListExtra(Intent.EXTRA_STREAM, images);
                startActivity(Intent.createChooser(share, "Share Image"));
                return true;
            case R.id.setAsWallpaper:
                WallpaperManager wallpaperManager = WallpaperManager.getInstance(getContext());
                Bitmap myBitmap =  BitmapFactory.decodeFile(imageResource);
                try {
                    wallpaperManager.setBitmap(myBitmap);
                    Toast.makeText(getContext(), "Wallpaper has been changed", Toast.LENGTH_SHORT).show();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return true;
            case R.id.back:
                //mCallback.onTrigger();
                Intent intent1 = new Intent(getContext(), MainActivity.class);
                startActivity(intent1);

                return true;
            case R.id.info:

                Intent intent = new Intent(getContext(), InfoActivity.class);
                Bundle extras = new Bundle();
                extras.putString("imageinfo", imageResource);
                intent.putExtras(extras);
                startActivity(intent);

                return true;
            case R.id.crop:

               /* CropImage.activity(Uri.fromFile(new File(imageResource)))
                        .setCropMenuCropButtonTitle("Crop")
                        .start(getContext(), this);
                */
                Uri destinationUri = Uri.fromFile(new File(getContext().getCacheDir(), "IMG_" + System.currentTimeMillis()));


                UCrop.of(Uri.fromFile(new File(imageResource)), destinationUri)
                        .withAspectRatio(16, 9)
                        .start((Activity) getContext());


               /* startActivityForResult(UCrop.of(Uri.fromFile(new File(imageResource)), destinationUri)
                        .getIntent(getContext()),UCrop.REQUEST_CROP);
                */

                /*ArrayList<String> images_paths = new ArrayList<String>();
                images_paths.add(imageResource);
                mCallback.onTrigger(images_paths);
                return true;
                */
            default:
                return super.onOptionsItemSelected(item);
        }
    }




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.photo_fragment, container, false);


        return inflater.inflate(R.layout.photo_fragment, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        imageView = (ImageView) view.findViewById(R.id.imageFragment);
        Glide.with(getContext()).load(imageResource).into(imageView);

        final PhotoViewAttacher pAttacher = new PhotoViewAttacher(imageView);
        pAttacher.setOnMatrixChangeListener(new PhotoViewAttacher.OnMatrixChangedListener() {
            @Override
            public void onMatrixChanged(RectF rect) {
                pAttacher.setAllowParentInterceptOnEdge(pAttacher.getScale()==1);
            }
        });
        pAttacher.update();

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }


}