package com.example.app3;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;


import com.bumptech.glide.Glide;

import java.util.ArrayList;

import static android.content.Context.MODE_PRIVATE;

public class myAdapter extends RecyclerView.Adapter<myAdapter.ViewHolder> {

    ArrayList<String> images_names;
    ArrayList<String> images_paths;
    boolean isViewWithCatalog = false;
    Context context;

    private View.OnClickListener itemClickListener;


    public myAdapter(Context context, ArrayList<String> images_names, ArrayList<String> images_paths, boolean isViewWithCatalog) {
        this.images_names = images_names;
        this.images_paths = images_paths;
        this.context = context;
        this.isViewWithCatalog = isViewWithCatalog;
    }


    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView myTextView;
        ImageView imageView;
        private Context context;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            myTextView = (TextView) itemView.findViewById(R.id.textView1);
            imageView = (ImageView) itemView.findViewById(R.id.imageView1);

            itemView.setTag(this);
            itemView.setOnClickListener(itemClickListener);

        }
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        Context context = viewGroup.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View itemView = null;

        if (isViewWithCatalog) {
            itemView = inflater.inflate(R.layout.recycler_view_item, viewGroup, false);
        }else{
            itemView = inflater.inflate(R.layout.recycler_view_item_2, viewGroup, false);
        }

        ViewHolder viewHolder = new ViewHolder(itemView);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {

        if(isViewWithCatalog) {
            viewHolder.myTextView.setText(images_names.get(i));
        }
        //Bitmap bitmap = decodeSampledBitmapFromFile(images_paths.get(i));
        //viewHolder.imageView.setImageBitmap(bitmap);
        Glide.with(context).load(images_paths.get(i)).centerCrop().into(viewHolder.imageView);

    }

    @Override
    public int getItemCount() {
        return images_names.size();
    }

    public void setOnItemClickListener(View.OnClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }



    private static Bitmap decodeSampledBitmapFromFile(String filePath) {
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(filePath, options);
        options.inSampleSize = calculateInSampleSize(options, 100,100);
        options.inJustDecodeBounds = false;

        return BitmapFactory.decodeFile(filePath, options);
    }

    public static int calculateInSampleSize(BitmapFactory.Options options, int reqWidth, int reqHeight) {

        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {

            final int halfHeight = height / 2;
            final int halfWidth = width / 2;

            while ((halfHeight / inSampleSize) >= reqHeight
                    && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2;
            }
        }

        return inSampleSize;
    }

}
