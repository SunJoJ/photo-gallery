package com.example.app3;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.DragEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.theartofdev.edmodo.cropper.CropImage;
import com.yalantis.ucrop.UCrop;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import uk.co.senab.photoview.PhotoViewAttacher;

import static android.app.Activity.RESULT_OK;
import static android.content.Context.MODE_PRIVATE;

public class PageFragment extends Fragment {

    private String imageResource;
    View rootView;
    ImageView imageView;
    MyInterface mCallback;

    public interface MyInterface {
        void onTrigger(ArrayList<String> images_paths);

    }

    public static PageFragment getInstance(String resourceID) {
        PageFragment f = new PageFragment();
        Bundle args = new Bundle();
        args.putString("image_source", resourceID);
        f.setArguments(args);
        return f;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        try {
            mCallback = (MyInterface ) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString()
                    + " must implement MyInterface ");
        }

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        imageResource = getArguments().getString("image_source");
        setHasOptionsMenu(true);

    }

    @Override
    public void onCreateOptionsMenu(
            Menu menu, MenuInflater inflater) {
        menu.clear();
        inflater.inflate(R.menu.full_image_menu, menu);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.share:
                Intent share = new Intent(Intent.ACTION_SEND_MULTIPLE);
                share.setType("image/png");
                ArrayList<Uri> images =new ArrayList<Uri>();
                images.add(Uri.parse("file:///"+imageResource));
                share.putParcelableArrayListExtra(Intent.EXTRA_STREAM, images);
                startActivity(Intent.createChooser(share, "Share Image"));
                return true;
            case R.id.setAsWallpaper:
                WallpaperManager wallpaperManager = WallpaperManager.getInstance(getContext());
                Bitmap myBitmap =  BitmapFactory.decodeFile(imageResource);
                try {
                    wallpaperManager.setBitmap(myBitmap);
                    Toast.makeText(getContext(), "Wallpaper has been changed", Toast.LENGTH_SHORT).show();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return true;
            case R.id.back:
                //mCallback.onTrigger();
                Intent intent1 = new Intent(getContext(), MainActivity.class);
                startActivity(intent1);

                return true;
            case R.id.info:

                Intent intent = new Intent(getContext(), InfoActivity.class);
                Bundle extras = new Bundle();
                extras.putString("imageinfo", imageResource);
                intent.putExtras(extras);
                startActivity(intent);

                return true;
            case R.id.crop:

               /* CropImage.activity(Uri.fromFile(new File(imageResource)))
                        .setCropMenuCropButtonTitle("Crop")
                        .start(getContext(), this);
                */

                SharedPreferences sharedPreferences = getActivity().getSharedPreferences("ChooseDirectory", MODE_PRIVATE);
                String path = sharedPreferences.getString("currentDirectory", "");

                File storageDir = new File(Environment.getExternalStorageDirectory() + "/" + path);

                String imageFileName = "IMG_" + System.currentTimeMillis() + "_NEW_";
                File distImage = null;
                try {
                    distImage = File.createTempFile(
                            imageFileName,  /* prefix */
                            ".jpg",         /* suffix */
                            storageDir      /* directory */
                    );
                } catch (IOException e) {
                    e.printStackTrace();
                }

                startActivityForResult(UCrop.of(Uri.fromFile(new File(imageResource)), Uri.fromFile(distImage))
                        .getIntent(getContext()), UCrop.REQUEST_CROP);

                /*ArrayList<String> images_paths = new ArrayList<String>();
                images_paths.add(imageResource);
                mCallback.onTrigger(images_paths);
                return true;
                */
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK && requestCode == UCrop.REQUEST_CROP) {

            final Uri resultUri = UCrop.getOutput(data);

            Intent intent1 = new Intent(getContext(), MainActivity.class);
            startActivity(intent1);

        } else if (resultCode == UCrop.RESULT_ERROR) {
            final Throwable cropError = UCrop.getError(data);

        } else if (requestCode == RESULT_OK && data != null) {

        }
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.photo_fragment, container, false);


        return inflater.inflate(R.layout.photo_fragment, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        imageView = (ImageView) view.findViewById(R.id.imageFragment);
        Glide.with(getContext()).load(imageResource).into(imageView);

        final PhotoViewAttacher pAttacher = new PhotoViewAttacher(imageView);
        pAttacher.setOnMatrixChangeListener(new PhotoViewAttacher.OnMatrixChangedListener() {
            @Override
            public void onMatrixChanged(RectF rect) {
                pAttacher.setAllowParentInterceptOnEdge(pAttacher.getScale()==1);
            }
        });
        pAttacher.update();

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }



    private Bitmap decodeSampledBitmapFromFile(String filePath) {
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(filePath, options);
        options.inSampleSize = calculateInSampleSize(options, 200,200);
        options.inJustDecodeBounds = false;

        return BitmapFactory.decodeFile(filePath, options);
    }

    public int calculateInSampleSize(BitmapFactory.Options options, int reqWidth, int reqHeight) {

        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {

            final int halfHeight = height / 2;
            final int halfWidth = width / 2;

            while ((halfHeight / inSampleSize) >= reqHeight
                    && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2;
            }
        }

        return inSampleSize;
    }


}